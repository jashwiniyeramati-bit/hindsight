"""
main.py — FastAPI backend for Hindsight AI Agent.

API Endpoints (matching frontend api.js):
  GET  /health
  GET  /docs           (FastAPI auto-docs)

  GET  /incidents              — list all incidents
  GET  /incidents/{id}         — get one incident
  GET  /incidents/{id}/analysis — AI analysis with Hindsight Recall

  GET  /memories               — list user's Hindsight memories
  GET  /learning               — learning timeline

  POST /feedback               — engineer feedback → Hindsight Retain

  (Internal)
  POST /chat                   — chat with AI agent
"""

import json
import logging
import os
import uuid
from datetime import datetime
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# ── Local modules ─────────────────────────────────────────────────────────────
from database import get_db, init_db
from memory import HindsightMemory
from agent import HindsightAgent

# ── Logging ───────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────────────

load_dotenv()  # reads backend/.env

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
HINDSIGHT_BASE_URL = os.getenv("HINDSIGHT_BASE_URL", "http://localhost:8888")
HINDSIGHT_API_KEY = os.getenv("HINDSIGHT_API_KEY", "") or None
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./hindsight_agent.db")
CORS_ORIGINS_RAW = os.getenv(
    "CORS_ORIGINS", "http://localhost:5173,http://localhost:3000"
)
CORS_ORIGINS = [o.strip() for o in CORS_ORIGINS_RAW.split(",") if o.strip()]

# Extract file path from sqlite:///./path
DB_FILE = DATABASE_URL.replace("sqlite:///./", "").replace("sqlite:///", "")

# ── App & startup ─────────────────────────────────────────────────────────────

from contextlib import asynccontextmanager

# Singletons — initialised at startup
_memory: Optional[HindsightMemory] = None
_agent: Optional[HindsightAgent] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global _memory, _agent

    # Init SQLite
    init_db(DB_FILE)
    logger.info("Database initialised: %s", DB_FILE)

    # Init Hindsight memory client
    _memory = HindsightMemory(
        base_url=HINDSIGHT_BASE_URL,
        api_key=HINDSIGHT_API_KEY,
    )
    logger.info(
        "Hindsight memory client: available=%s, url=%s",
        _memory.available,
        HINDSIGHT_BASE_URL,
    )

    # Init AI agent
    if not GEMINI_API_KEY:
        logger.warning("GEMINI_API_KEY not set — AI features will fail")
    _agent = HindsightAgent(memory=_memory, gemini_api_key=GEMINI_API_KEY)
    logger.info("HindsightAgent initialised")

    yield


app = FastAPI(
    title="Hindsight AI Agent API",
    description=(
        "Memory-aware incident response copilot backed by Hindsight (RETAIN/RECALL/REFLECT) "
        "and Google Gemini."
    ),
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Default user (demo) ───────────────────────────────────────────────────────

DEFAULT_USER_ID = "user-default"


def _get_user_id(user_id: Optional[str] = None) -> str:
    return user_id or DEFAULT_USER_ID


# ─────────────────────────────────────────────────────────────────────────────
# HEALTH
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/health", tags=["Health"])
def health():
    return {
        "status": "ok",
        "service": "hindsight-ai-agent",
        "hindsight_available": _memory.available if _memory else False,
        "gemini_configured": bool(GEMINI_API_KEY),
        "timestamp": datetime.utcnow().isoformat(),
    }


# ─────────────────────────────────────────────────────────────────────────────
# INCIDENTS
# ─────────────────────────────────────────────────────────────────────────────

def _row_to_incident(row) -> dict:
    return dict(row)


@app.get("/incidents", tags=["Incidents"])
def list_incidents():
    db = get_db()
    rows = db.execute(
        "SELECT * FROM incidents ORDER BY detected_at DESC"
    ).fetchall()
    return [_row_to_incident(r) for r in rows]


@app.get("/incidents/{incident_id}", tags=["Incidents"])
def get_incident(incident_id: str):
    db = get_db()
    row = db.execute(
        "SELECT * FROM incidents WHERE id = ?", (incident_id,)
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail=f"Incident {incident_id} not found")
    return _row_to_incident(row)


# ─────────────────────────────────────────────────────────────────────────────
# AI ANALYSIS  (GET /incidents/{id}/analysis)
# ─────────────────────────────────────────────────────────────────────────────

# Hard-coded baseline memories to RETAIN on first analysis (demo seed)
_BASELINE_MEMORIES = {
    "INC-104": [
        "INC-087: Payment API MongoDB connection failures after network configuration change. Resolution: Network configuration rollback resolved the incident in 14 minutes.",
        "INC-064: Orders API database connection failures caused by infrastructure configuration. Resolution: Configuration rollback restored database connectivity.",
        "INC-041: Payment API MongoDB connectivity degradation after connection limit changes. Resolution: Connection limits were adjusted and service recovered.",
    ],
    "INC-103": [
        "INC-076: Auth Service authentication failures after identity provider configuration changes. Resolution: Rolling back the authentication configuration resolved the incident.",
        "INC-052: Identity Service login failures caused by an authentication policy update. Resolution: Reverting the policy restored authentication.",
        "INC-029: Auth Service elevated authentication errors after provider configuration changes. Resolution: Previous provider configuration was restored.",
    ],
    "INC-102": [
        "INC-069: Cache Service Redis memory exhaustion caused by stale entries and increased traffic. Resolution: Stale entries were cleared and cache capacity was increased.",
        "INC-044: Cache Service cache memory growth exceeded configured limits. Resolution: Memory allocation was increased and stale data was removed.",
        "INC-018: Cache Service Redis memory pressure during increased traffic. Resolution: Cache capacity was scaled to restore service.",
    ],
}


def _ensure_baseline_memories(incident_id: str, user_id: str) -> None:
    """Seed baseline memories for demo incidents if Hindsight is available."""
    if not (_memory and _memory.available):
        return
    memories = _BASELINE_MEMORIES.get(incident_id, [])
    for m in memories:
        _memory.retain(user_id=user_id, content=m)


@app.get("/incidents/{incident_id}/analysis", tags=["Incidents"])
def get_ai_analysis(
    incident_id: str,
    user_id: str = Query(default=DEFAULT_USER_ID),
):
    db = get_db()
    row = db.execute(
        "SELECT * FROM incidents WHERE id = ?", (incident_id,)
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail=f"Incident {incident_id} not found")

    incident = _row_to_incident(row)

    # Seed baseline memories for this demo incident
    _ensure_baseline_memories(incident_id, user_id)

    # Run agent analysis
    result = _agent.analyse_incident(user_id=user_id, incident=incident)

    # Attach incident data and format memories as frontend expects
    memories_recalled = result.get("memories_recalled", [])
    analysis = result.get("analysis", {})
    recommendations = analysis.get("recommendations", [])

    # Build response matching frontend AIAnalysis component structure
    formatted_memories = []
    for i, m in enumerate(memories_recalled):
        text = m.get("text", "")
        formatted_memories.append({
            "id": f"MEM-{i+1:03d}",
            "description": text[:200] if text else "Historical memory",
            "match": f"{max(90 - i*7, 60)}%",
            "service": incident.get("service", ""),
            "outcome": "Successfully Resolved",
        })

    return {
        "incident_id": incident_id,
        "incident": incident,
        "memories": formatted_memories,
        "memories_recalled_raw": memories_recalled,
        "reflect_insight": result.get("reflect_insight", ""),
        "reasoning": analysis.get("reasoning", ""),
        "recommendation": recommendations[0]["action"] if recommendations else "Review recent changes",
        "recommendation_reason": recommendations[0]["reason"] if recommendations else "",
        "confidence": f"{analysis.get('overall_confidence', 75)}%",
        "all_recommendations": recommendations,
        "root_cause": analysis.get("root_cause", ""),
        "pattern_summary": analysis.get("pattern_summary", ""),
        "hindsight_available": _memory.available if _memory else False,
    }


# ─────────────────────────────────────────────────────────────────────────────
# MEMORIES   (GET /memories)
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/memories", tags=["Memory"])
def get_memories(
    search: Optional[str] = Query(default=None),
    sort: Optional[str] = Query(default="relevance"),
    user_id: str = Query(default=DEFAULT_USER_ID),
):
    """Return memories from Hindsight + demo historical incidents from DB."""
    db = get_db()

    # Fetch resolved incidents as memories
    rows = db.execute(
        """
        SELECT id, service, title, error, detected_at,
               'Successfully Resolved' AS outcome
        FROM incidents
        WHERE status = 'resolved'
        ORDER BY detected_at DESC
        """,
    ).fetchall()

    # Also pull any feedback that was retained
    feedback_rows = db.execute(
        """
        SELECT f.id, f.incident_id, f.decision, f.outcome, f.comment,
               f.recommendation, f.service, f.created_at,
               i.title, i.error
        FROM feedback f
        JOIN incidents i ON i.id = f.incident_id
        ORDER BY f.created_at DESC
        LIMIT 20
        """,
    ).fetchall()

    memories = []

    for r in rows:
        mem = {
            "id": r["id"],
            "title": f"{r['service']} — {r['title']}",
            "rootCause": r["error"],
            "resolution": "See historical record",
            "outcome": r["outcome"],
            "age": _relative_time(r["detected_at"]),
            "match": 85,
        }
        memories.append(mem)

    for fb in feedback_rows:
        outcome_map = {
            "resolved": "Successfully Resolved",
            "partial": "Partially Resolved",
            "failed": "Resolution Failed",
        }
        mem = {
            "id": fb["incident_id"],
            "title": f"{fb['service']} — {fb['title']}",
            "rootCause": fb["error"],
            "resolution": fb["recommendation"] or "See feedback",
            "outcome": outcome_map.get(fb["outcome"], fb["outcome"]),
            "age": _relative_time(fb["created_at"]),
            "match": 100,
            "newMemory": True,
            "decision": fb["decision"],
            "comment": fb["comment"] or "",
        }
        memories.append(mem)

    # Search filter
    if search:
        q = search.lower()
        memories = [
            m for m in memories
            if q in json.dumps(m).lower()
        ]

    # Sort
    if sort == "match":
        memories.sort(key=lambda m: m.get("match", 0), reverse=True)
    elif sort == "recent":
        memories.sort(key=lambda m: m.get("age", ""), reverse=False)

    # Hindsight live memories (if available)
    live_memories = []
    if _memory and _memory.available:
        live_memories = _memory.list_memories(user_id)

    return {
        "memories": memories,
        "live_memories": live_memories,
        "total": len(memories),
        "hindsight_available": _memory.available if _memory else False,
    }


# ─────────────────────────────────────────────────────────────────────────────
# LEARNING TIMELINE   (GET /learning)
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/learning", tags=["Learning"])
def get_learning(user_id: str = Query(default=DEFAULT_USER_ID)):
    """Return learning timeline events."""
    db = get_db()

    feedback_rows = db.execute(
        """
        SELECT f.*, i.service, i.title, i.error
        FROM feedback f
        JOIN incidents i ON i.id = f.incident_id
        ORDER BY f.created_at DESC
        LIMIT 20
        """,
    ).fetchall()

    timeline = []
    for fb in feedback_rows:
        timeline.append({
            "id": fb["id"],
            "incident_id": fb["incident_id"],
            "service": fb["service"],
            "title": fb["title"],
            "decision": fb["decision"],
            "outcome": fb["outcome"],
            "comment": fb["comment"] or "",
            "retained": bool(fb["hindsight_retained"]),
            "timestamp": fb["created_at"],
            "age": _relative_time(fb["created_at"]),
        })

    # Baseline timeline items
    baseline = [
        {
            "id": "BASE-001",
            "incident_id": "INC-103",
            "service": "Auth Service",
            "title": "Authentication pattern learned",
            "decision": "accepted",
            "outcome": "resolved",
            "comment": "Engineer resolution was retained after successful incident recovery.",
            "retained": True,
            "timestamp": "2026-09-29 08:00:00",
            "age": "today",
        },
        {
            "id": "BASE-002",
            "incident_id": "INC-087",
            "service": "Payment API",
            "title": "Network configuration pattern updated",
            "decision": "accepted",
            "outcome": "resolved",
            "comment": "Historical outcomes improved the context available for future recommendations.",
            "retained": True,
            "timestamp": "2026-09-28 12:00:00",
            "age": "yesterday",
        },
    ]

    all_events = timeline + baseline

    db_feedback_count = db.execute("SELECT COUNT(*) FROM feedback").fetchone()[0]

    return {
        "events": all_events,
        "stats": {
            "total_memories": 128 + db_feedback_count,
            "successful_outcomes": 117,
            "patterns_learned": 42,
            "feedback_signals": 95 + db_feedback_count,
        },
        "hindsight_available": _memory.available if _memory else False,
    }


# ─────────────────────────────────────────────────────────────────────────────
# FEEDBACK   (POST /feedback)
# ─────────────────────────────────────────────────────────────────────────────

class FeedbackRequest(BaseModel):
    incident_id: str
    decision: str        # accepted | modified | rejected
    outcome: str         # resolved | partial | failed
    comment: Optional[str] = ""
    recommendation: Optional[str] = ""
    service: Optional[str] = ""
    user_id: Optional[str] = DEFAULT_USER_ID


@app.post("/feedback", status_code=201, tags=["Feedback"])
def submit_feedback(body: FeedbackRequest):
    db = get_db()
    user_id = _get_user_id(body.user_id)

    feedback_id = f"FB-{uuid.uuid4().hex[:8].upper()}"
    db.execute(
        """
        INSERT INTO feedback
            (id, incident_id, user_id, decision, outcome, comment,
             recommendation, service, hindsight_retained)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
        """,
        (
            feedback_id,
            body.incident_id,
            user_id,
            body.decision,
            body.outcome,
            body.comment or "",
            body.recommendation or "",
            body.service or "",
        ),
    )
    db.commit()

    # ── RETAIN the feedback as a Hindsight memory ─────────────────────────────
    retain_content = (
        f"Incident {body.incident_id} ({body.service}): "
        f"Engineer {body.decision} recommendation '{body.recommendation}'. "
        f"Outcome: {body.outcome}."
    )
    if body.comment:
        retain_content += f" Engineer note: {body.comment}"

    retain_result = {"status": "skipped"}
    if _memory:
        retain_result = _memory.retain(user_id=user_id, content=retain_content)
        if retain_result.get("status") == "ok":
            db.execute(
                "UPDATE feedback SET hindsight_retained=1 WHERE id=?",
                (feedback_id,),
            )
            db.commit()

    # REFLECT after retaining (generate insight if enough memory)
    reflect_insight = ""
    if _memory and _memory.available:
        reflect_insight = _memory.reflect(
            user_id=user_id,
            query=f"{body.service} {body.outcome} incident resolution pattern",
        )

    return {
        "id": feedback_id,
        "incident_id": body.incident_id,
        "hindsight_retained": retain_result.get("status") == "ok",
        "reflect_insight": reflect_insight,
        "message": "Feedback recorded and retained in Hindsight memory.",
        "memory": {
            "incidentId": body.incident_id,
            "service": body.service,
            "decision": body.decision,
            "outcome": body.outcome,
            "recommendation": body.recommendation,
            "comment": body.comment,
        },
    }


# ─────────────────────────────────────────────────────────────────────────────
# CHAT   (POST /chat)
# ─────────────────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    message: str
    incident_id: Optional[str] = None
    conversation_id: Optional[str] = None
    user_id: Optional[str] = DEFAULT_USER_ID


@app.post("/chat", tags=["Chat"])
def chat(body: ChatRequest):
    user_id = _get_user_id(body.user_id)
    db = get_db()

    # Resolve conversation
    conv_id = body.conversation_id
    if not conv_id:
        conv_id = f"CONV-{uuid.uuid4().hex[:8]}"
        db.execute(
            "INSERT OR IGNORE INTO conversations (id, user_id, incident_id, title) VALUES (?, ?, ?, ?)",
            (conv_id, user_id, body.incident_id, f"Chat {datetime.utcnow().strftime('%H:%M')}"),
        )
        db.commit()

    # Fetch conversation history
    history_rows = db.execute(
        """
        SELECT role, content FROM messages
        WHERE conversation_id = ?
        ORDER BY created_at ASC
        LIMIT 20
        """,
        (conv_id,),
    ).fetchall()
    history = [{"role": r["role"], "content": r["content"]} for r in history_rows]

    # Resolve incident context
    incident_context = None
    if body.incident_id:
        row = db.execute(
            "SELECT * FROM incidents WHERE id = ?", (body.incident_id,)
        ).fetchone()
        if row:
            incident_context = dict(row)
            _ensure_baseline_memories(body.incident_id, user_id)

    # Run the agent
    result = _agent.chat(
        user_id=user_id,
        user_message=body.message,
        incident_context=incident_context,
        conversation_history=history,
    )

    ai_response = result["response"]
    memories_used = result.get("memories_used", [])

    # Store messages in DB
    user_msg_id = f"MSG-{uuid.uuid4().hex[:8]}"
    ai_msg_id = f"MSG-{uuid.uuid4().hex[:8]}"
    db.execute(
        "INSERT INTO messages (id, conversation_id, role, content) VALUES (?, ?, 'user', ?)",
        (user_msg_id, conv_id, body.message),
    )
    db.execute(
        "INSERT INTO messages (id, conversation_id, role, content, memories_used) VALUES (?, ?, 'assistant', ?, ?)",
        (ai_msg_id, conv_id, ai_response, json.dumps(memories_used)),
    )
    db.commit()

    return {
        "conversation_id": conv_id,
        "message_id": ai_msg_id,
        "response": ai_response,
        "memories_used": memories_used,
        "reflect_insight": result.get("reflect_insight", ""),
        "retained": result.get("retained", False),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Utility
# ─────────────────────────────────────────────────────────────────────────────

def _relative_time(ts: Optional[str]) -> str:
    if not ts:
        return "unknown"
    try:
        dt = datetime.fromisoformat(ts.replace(" ", "T"))
        delta = datetime.utcnow() - dt
        days = delta.days
        if days == 0:
            return "today"
        if days == 1:
            return "yesterday"
        if days < 7:
            return f"{days} days ago"
        if days < 30:
            weeks = days // 7
            return f"{weeks} week{'s' if weeks > 1 else ''} ago"
        months = days // 30
        return f"{months} month{'s' if months > 1 else ''} ago"
    except Exception:  # noqa: BLE001
        return ts


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host=os.getenv("APP_HOST", "0.0.0.0"),
        port=int(os.getenv("APP_PORT", 8000)),
        reload=True,
    )
