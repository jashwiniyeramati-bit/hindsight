"""
memory.py — Hindsight memory client wrapper.

Wraps the real hindsight_client (https://github.com/vectorize-io/hindsight)
RETAIN / RECALL / REFLECT operations.

If the Hindsight server is not reachable we fall back gracefully so the
rest of the API still works.
"""

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

# ── Try to import the real hindsight client ───────────────────────────────────
try:
    from hindsight_client import Hindsight as _HindsightSDK  # type: ignore
    _SDK_AVAILABLE = True
except ImportError:
    _HindsightSDK = None
    _SDK_AVAILABLE = False
    logger.warning("hindsight-client not installed; memory operations will be no-ops")


class HindsightMemory:
    """
    Thin facade over the vectorize-io Hindsight SDK.

    Each user gets an isolated memory bank: bank_id = f"hindsight-{user_id}"
    """

    def __init__(self, base_url: str, api_key: Optional[str] = None) -> None:
        self._base_url = base_url
        self._api_key = api_key
        self._client: Optional[Any] = None
        self._available = False

        if not _SDK_AVAILABLE:
            return

        try:
            kwargs: dict = {"base_url": base_url}
            if api_key:
                kwargs["api_key"] = api_key
            self._client = _HindsightSDK(**kwargs)
            # Check if server is actually reachable
            import urllib.request
            try:
                urllib.request.urlopen(f"{base_url.rstrip('/')}/health", timeout=1.5)
                self._available = True
                logger.info("Hindsight server is live at %s", base_url)
            except Exception:
                self._available = False
                logger.info(
                    "Hindsight server not detected at %s. Running with local SQLite fallback until Hindsight server starts.",
                    base_url,
                )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Could not initialise Hindsight client: %s", exc)

    def check_connection(self) -> bool:
        """Check live connection to Hindsight server."""
        import urllib.request
        try:
            urllib.request.urlopen(f"{self._base_url.rstrip('/')}/health", timeout=1.5)
            self._available = True
            return True
        except Exception:
            self._available = False
            return False

    # ── Internal helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _bank_id(user_id: str) -> str:
        """Each user has their own isolated memory bank."""
        return f"hindsight-{user_id}"

    # ── Public API ────────────────────────────────────────────────────────────

    @property
    def available(self) -> bool:
        return self._available

    def retain(self, user_id: str, content: str) -> dict:
        """
        RETAIN — store information in the user's memory bank.

        Docs: client.retain(bank_id, content)
        """
        if not self._available or not content.strip():
            return {"status": "skipped", "reason": "hindsight unavailable or empty content"}

        try:
            result = self._client.retain(
                bank_id=self._bank_id(user_id),
                content=content,
            )
            logger.debug("RETAIN ok for user=%s", user_id)
            return {"status": "ok", "result": str(result)}
        except Exception as exc:  # noqa: BLE001
            logger.warning("RETAIN failed: %s", exc)
            return {"status": "error", "error": str(exc)}

    def recall(self, user_id: str, query: str, top_k: int = 5) -> list[dict]:
        """
        RECALL — retrieve semantically relevant memories.

        Docs: client.recall(bank_id, query) → RecallResponse
              response.results → list[RecallResult]
              each result has .text
        """
        if not self._available:
            return []

        try:
            response = self._client.recall(
                bank_id=self._bank_id(user_id),
                query=query,
            )
            results = []
            for r in (response.results or [])[:top_k]:
                results.append({"text": getattr(r, "text", str(r))})
            logger.debug("RECALL returned %d memories for user=%s", len(results), user_id)
            return results
        except Exception as exc:  # noqa: BLE001
            logger.warning("RECALL failed: %s", exc)
            return []

    def reflect(self, user_id: str, query: str) -> str:
        """
        REFLECT — generate a higher-level insight from accumulated memories.

        Docs: client.reflect(bank_id, query) → ReflectResponse
              response.text
        """
        if not self._available:
            return ""

        try:
            response = self._client.reflect(
                bank_id=self._bank_id(user_id),
                query=query,
            )
            text = getattr(response, "text", "") or ""
            logger.debug("REFLECT ok for user=%s", user_id)
            return text
        except Exception as exc:  # noqa: BLE001
            logger.warning("REFLECT failed: %s", exc)
            return ""

    def list_memories(self, user_id: str) -> list[dict]:
        """
        List all memory units in the user's bank.
        Uses the low-level async documents.list_documents API.
        """
        if not self._available:
            return []

        try:
            import asyncio

            docs = asyncio.run(
                self._client.documents.list_documents(self._bank_id(user_id))
            )
            items = []
            for d in (docs.documents or []):
                items.append({
                    "id": getattr(d, "id", ""),
                    "content": getattr(d, "content", ""),
                    "created_at": str(getattr(d, "created_at", "")),
                })
            return items
        except Exception as exc:  # noqa: BLE001
            logger.warning("list_memories failed: %s", exc)
            return []
