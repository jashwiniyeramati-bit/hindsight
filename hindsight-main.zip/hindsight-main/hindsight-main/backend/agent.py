"""
agent.py — Memory-aware AI Agent using Gemini + Hindsight.

Flow per message:
  1. RECALL   — retrieve relevant memories for this query
  2. REFLECT  — if enough context, generate high-level insight
  3. LLM      — call Gemini with system prompt + memories + conversation
  4. RETAIN   — store the important parts of the exchange
"""

import json
import logging
import os
from typing import Optional

import google.generativeai as genai

from memory import HindsightMemory

logger = logging.getLogger(__name__)

# ── Gemini setup ──────────────────────────────────────────────────────────────

GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")

_SYSTEM_PROMPT = """You are Hindsight AI Agent — an expert incident response copilot for software engineers.

Your capabilities:
- Analyse active production incidents with precision
- Recall similar historical incidents from Hindsight memory
- Synthesise patterns and recommend resolution steps
- Learn from engineer feedback to improve future recommendations

When answering:
1. Reference any recalled historical memories explicitly
2. Provide concrete, actionable recommendations
3. Include confidence level when making recommendations
4. Stay focused on the current incident context

You have access to Hindsight's persistent memory, which stores patterns from resolved incidents.
"""


class HindsightAgent:
    """Memory-aware agent: RECALL → LLM → RETAIN."""

    def __init__(self, memory: HindsightMemory, gemini_api_key: str) -> None:
        self._memory = memory
        genai.configure(api_key=gemini_api_key)
        self._model = genai.GenerativeModel(
            model_name=GEMINI_MODEL,
            system_instruction=_SYSTEM_PROMPT,
        )

    # ── Main entry point ──────────────────────────────────────────────────────

    def chat(
        self,
        user_id: str,
        user_message: str,
        incident_context: Optional[dict] = None,
        conversation_history: Optional[list[dict]] = None,
    ) -> dict:
        """
        Full RECALL → REFLECT → LLM → RETAIN flow.

        Returns:
            {
                "response": str,           # AI reply
                "memories_used": list,     # recalled snippets
                "reflect_insight": str,    # REFLECT output (may be empty)
                "retained": bool,          # whether RETAIN was called
            }
        """
        query = self._build_recall_query(user_message, incident_context)

        # ── 1. RECALL ─────────────────────────────────────────────────────────
        memories = self._memory.recall(user_id=user_id, query=query)

        # ── 2. REFLECT (on substantive queries about incidents) ───────────────
        reflect_insight = ""
        if incident_context and memories:
            reflect_insight = self._memory.reflect(
                user_id=user_id, query=query
            )

        # ── 3. Build prompt + call Gemini ─────────────────────────────────────
        prompt = self._build_prompt(
            user_message=user_message,
            incident_context=incident_context,
            memories=memories,
            reflect_insight=reflect_insight,
            conversation_history=conversation_history or [],
        )

        try:
            gemini_response = self._model.generate_content(prompt)
            ai_text = gemini_response.text
        except Exception as exc:  # noqa: BLE001
            logger.error("Gemini call failed: %s", exc)
            ai_text = (
                "I encountered an error generating a response. "
                "Please check the logs and retry."
            )

        # ── 4. RETAIN — store the user message + outcome ─────────────────────
        retain_content = self._build_retain_content(
            user_message=user_message,
            ai_response=ai_text,
            incident_context=incident_context,
        )
        self._memory.retain(user_id=user_id, content=retain_content)

        return {
            "response": ai_text,
            "memories_used": memories,
            "reflect_insight": reflect_insight,
            "retained": True,
        }

    # ── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _build_recall_query(message: str, incident_context: Optional[dict]) -> str:
        if incident_context:
            service = incident_context.get("service", "")
            error = incident_context.get("error", "")
            return f"{service} {error} {message}".strip()
        return message

    @staticmethod
    def _build_prompt(
        user_message: str,
        incident_context: Optional[dict],
        memories: list[dict],
        reflect_insight: str,
        conversation_history: list[dict],
    ) -> str:
        parts: list[str] = []

        # Incident context
        if incident_context:
            parts.append("=== CURRENT INCIDENT ===")
            parts.append(f"ID: {incident_context.get('id', 'N/A')}")
            parts.append(f"Service: {incident_context.get('service', 'N/A')}")
            parts.append(f"Error: {incident_context.get('error', 'N/A')}")
            parts.append(f"Severity: {incident_context.get('severity', 'N/A')}")
            if incident_context.get("description"):
                parts.append(f"Description: {incident_context['description']}")
            parts.append("")

        # Recalled memories (RECALL)
        if memories:
            parts.append("=== HINDSIGHT RECALLED MEMORIES ===")
            for i, mem in enumerate(memories, 1):
                parts.append(f"[Memory {i}] {mem.get('text', '')}")
            parts.append("")

        # High-level insight (REFLECT)
        if reflect_insight:
            parts.append("=== HINDSIGHT REFLECTION ===")
            parts.append(reflect_insight)
            parts.append("")

        # Conversation history
        if conversation_history:
            parts.append("=== CONVERSATION HISTORY ===")
            for msg in conversation_history[-6:]:  # last 6 exchanges
                role = "Engineer" if msg["role"] == "user" else "Assistant"
                parts.append(f"{role}: {msg['content']}")
            parts.append("")

        # Current user message
        parts.append("=== ENGINEER MESSAGE ===")
        parts.append(user_message)

        return "\n".join(parts)

    @staticmethod
    def _build_retain_content(
        user_message: str,
        ai_response: str,
        incident_context: Optional[dict],
    ) -> str:
        """Build a concise memory string to retain."""
        lines = []
        if incident_context:
            lines.append(
                f"Incident {incident_context.get('id', '')} — "
                f"{incident_context.get('service', '')} — "
                f"{incident_context.get('error', '')}"
            )
        lines.append(f"Question: {user_message[:300]}")
        lines.append(f"Answer: {ai_response[:500]}")
        return " | ".join(lines)

    # ── Analysis ──────────────────────────────────────────────────────────────

    def analyse_incident(self, user_id: str, incident: dict) -> dict:
        """
        Generate a structured AI analysis for an incident using RECALL + REFLECT.
        """
        query = (
            f"{incident.get('service', '')} "
            f"{incident.get('error', '')} "
            f"{incident.get('description', '')}"
        )

        memories = self._memory.recall(user_id=user_id, query=query, top_k=5)
        reflect_insight = self._memory.reflect(user_id=user_id, query=query)

        prompt = f"""Analyse this production incident and provide:
1. Root cause analysis
2. Top 3 recommended actions (ranked by confidence)
3. Confidence score (0-100)
4. Historical pattern match summary

Incident:
- ID: {incident.get('id')}
- Service: {incident.get('service')}
- Error: {incident.get('error')}
- Severity: {incident.get('severity')}
- Description: {incident.get('description', '')}

Recalled Memories:
{chr(10).join(m.get('text', '') for m in memories) if memories else 'No historical memories found.'}

Reflection:
{reflect_insight if reflect_insight else 'N/A'}

Respond with valid JSON only:
{{
  "root_cause": "...",
  "recommendations": [
    {{"action": "...", "reason": "...", "confidence": 92}},
    {{"action": "...", "reason": "...", "confidence": 78}},
    {{"action": "...", "reason": "...", "confidence": 65}}
  ],
  "overall_confidence": 88,
  "pattern_summary": "...",
  "reasoning": "..."
}}"""

        try:
            response = self._model.generate_content(prompt)
            raw = response.text.strip()
            # Strip markdown fences if present
            if raw.startswith("```"):
                raw = raw.split("```")[1]
                if raw.startswith("json"):
                    raw = raw[4:]
            analysis = json.loads(raw)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Analysis JSON parse failed: %s", exc)
            analysis = {
                "root_cause": "Unable to determine — check logs",
                "recommendations": [
                    {
                        "action": "Review recent deployments and configuration changes",
                        "reason": "Most common cause of service failures",
                        "confidence": 60,
                    }
                ],
                "overall_confidence": 50,
                "pattern_summary": "Analysis failed — using fallback",
                "reasoning": str(exc),
            }

        return {
            "incident_id": incident.get("id"),
            "memories_recalled": memories,
            "reflect_insight": reflect_insight,
            "analysis": analysis,
        }
